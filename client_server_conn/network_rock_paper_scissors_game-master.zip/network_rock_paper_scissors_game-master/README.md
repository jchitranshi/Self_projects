# network_rock_paper_scissors_game
This repository contains complete source codes for a network rock-paper-scissors game. See game session video here: https://youtu.be/-WJN1uhbUhw

To run the application:

1. Make sure you have python installed and setup on your system. App is tested on Python 2.7
2. Download or clone the repository
3. To start the server: python game_server.py
4. Click "Start" button on the Server window
5. Lauch two clients. To start a client: python game_client.py
6. Enter player name and click on "Connect" button

* The game starts when two clients (players) are connected. 
* Enjoy!
